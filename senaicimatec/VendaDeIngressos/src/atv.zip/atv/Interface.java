package atv;

public interface Interface {
	
	public void mostrarValorDoIngresso(Ingresso ingresso);

	public void statusCarrinho();
		
	public void calcularValorTotal();
	
	public void buscarIngressos(Integer ID);
		
}
