package primeiraAv;

public interface Produtos {
	public Double calcularValorTotalDosProdutos();
	public void statusDaCompra();
}
