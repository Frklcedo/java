package br.senai.av01;

public interface PessoaImp {
	
	// Métodos de PessoaImp [ calcularIR() ,  status()  ]
	public void status();
	public Double calcularIR();

}


